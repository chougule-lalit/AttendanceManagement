export const NavbarData = [
  {
    routelink: 'dashboard',
    icon: 'fa-solid fa-house',
    label: 'Dashboard'
  }
]
