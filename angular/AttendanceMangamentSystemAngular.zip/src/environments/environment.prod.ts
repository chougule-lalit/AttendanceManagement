export const environment = {
  production: true,
  ApiBaseUrl: 'https://localhost:5000/',
};
